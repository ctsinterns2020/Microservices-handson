package com.microservices.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.model.Loan;

import org.springframework.web.bind.annotation.PathVariable;

@RestController
public class loanController {

	@GetMapping("/loan/{number}")
public Loan getDetails(@PathVariable int number)
{
	Loan obj=new Loan();
	
	obj.setNumber(number);
	obj.setType("Car");
	obj.setLoan(50000);
	obj.setEmi(3567);
	obj.setTenure(18);
	
	return obj;
}

}
