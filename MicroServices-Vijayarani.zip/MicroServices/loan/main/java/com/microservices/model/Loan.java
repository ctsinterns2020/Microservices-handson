package com.microservices.model;

public class Loan {
int number;
String type;
int loan;
int emi;
int tenure;

public int getLoan() {
	return loan;
}
public void setLoan(int loan) {
	this.loan = loan;
}
public int getEmi() {
	return emi;
}
public void setEmi(int emi) {
	this.emi = emi;
}
public int getTenure() {
	return tenure;
}
public void setTenure(int tenure) {
	this.tenure = tenure;
}


public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}


}
