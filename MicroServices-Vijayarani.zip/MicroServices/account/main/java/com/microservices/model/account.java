package com.microservices.model;

public class account {
int number;
String type;
float balance;
public int getNumber() {
	return number;
}
public void setNumber(int number) {
	this.number = number;
}
public String getType() {
	return type;
}
public void setType(String type) {
	this.type = type;
}
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}

}
