package com.microservices.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservices.model.account;

import org.springframework.web.bind.annotation.PathVariable;

@RestController
public class accountController {

	@GetMapping("/account/{number}")
public account getDetails(@PathVariable int number)
{
	account obj=new account();
	
	obj.setNumber(number);
	obj.setBalance(45000);
	obj.setType("Savings");
	
	return obj;
}

}
